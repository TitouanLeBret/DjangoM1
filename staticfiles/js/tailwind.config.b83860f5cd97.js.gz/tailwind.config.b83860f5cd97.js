/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./siteCourse/templates/*.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}

